﻿#nullable disable
namespace EToolSystem.ViewModel
{
    public class EmployeeInfo
    {
        public int EmployeeID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }
}
